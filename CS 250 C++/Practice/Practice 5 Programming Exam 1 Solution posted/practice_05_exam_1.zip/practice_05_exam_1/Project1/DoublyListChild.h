/*
	(name header)
*/

#pragma once

#include "DoublyList.h"

class DoublyListChild : public DoublyList
{
public:
	// Definition insertBeforeLast
	/*
		Parameter: An integer storing new data to insert in the list.
		Restrictions: Can create only 1 pointer.
		Assumptions: The calling object has at least 2 nodes.			
	*/
	// Your code here...



	// Definition printBackwards
	/*
		Restrictions: Can create only 1 pointer.
		Assumptions: The calling object has at least one node.
	*/
	// Your code here...




	// Do NOT write below this line.
	DoublyListChild() {}
	~DoublyListChild() {}
};