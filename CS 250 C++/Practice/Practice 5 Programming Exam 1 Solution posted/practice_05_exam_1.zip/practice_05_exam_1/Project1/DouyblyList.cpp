#include "DoublyList.h"

ostream& operator<<(ostream& out, const DoublyList& theList)
{
	Node *current = theList.first;
	while (current != nullptr)
	{
		out << current->getData() << " ";
		current = current->getNext();
	}
	return out;
}

DoublyList::DoublyList()
{
	first = nullptr;
	last = nullptr;
	count = 0;
}

void DoublyList::insert(const vector<int>& v)
{
	first = last = new Node(v[0], nullptr, nullptr);
	size_t size = v.size();
	for (size_t i = 1; i < size; ++i)
	{
		last->setNext(new Node(v[i], last, nullptr));
		last = last->getNext();
	}
	count = static_cast<int>(size);
}

void DoublyList::destroyList()
{
	while (first != nullptr)
	{
		Node  *temp = first;
		first = first->getNext();
		delete temp;
		temp = nullptr;
	}
	last = nullptr;
	count = 0;
}

DoublyList::~DoublyList()
{
	destroyList();
}





