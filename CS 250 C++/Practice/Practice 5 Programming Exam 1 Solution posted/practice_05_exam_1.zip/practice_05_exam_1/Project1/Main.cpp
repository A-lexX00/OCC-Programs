#include "DoublyListChild.h"

#include <iostream>
#include <string>
#include <vector>
using namespace std;

void test_insertBeforeLast(DoublyListChild& dll, int toInsert)
{
	// Uncomment for testing
	dll.insertBeforeLast(toInsert);
}

void test_printBackwards(DoublyListChild& dll)
{
	// Uncomment for testing
	dll.printBackwards();
}

int main()
{
	vector<vector<int>> v = {
		{ 32, 12 },
		{ 45, 23, 98 },
		{ 56, 12, 46, 78, 10, 23 },
	};	

	cout << "TEST: insertBeforeLast\n\n";
	{
		vector<int> toInsert = { 100, 200, 300 };

		size_t sizeOuterV = v.size();
		for (size_t i = 0; i < sizeOuterV; ++i)
		{
			DoublyListChild dll1;
			dll1.insert(v[i]);
			cout << "   Initial list: " << dll1 << endl;			
			vector<int> tempVector = v[i];
			auto iter = tempVector.begin() + (tempVector.size() - 1);
			tempVector.insert(iter, toInsert[i]);
			cout << "Expected output: ";
			for (auto i : tempVector) cout << i << " ";
			test_insertBeforeLast(dll1, toInsert[i]);
			cout << "\n    Your output: " << dll1 << endl << endl;
		}
	}

	cout << "\n=================================================\n";
	cout << "TEST: printBackwards\n\n";
	{
		size_t sizeOuterV = v.size();
		for (size_t i = 0; i < sizeOuterV; ++i)
		{
			DoublyListChild dll1;
			dll1.insert(v[i]);
			cout << "   Initial list: " << dll1 << endl;			
			vector<int> tempVector = v[i];
			auto riter = tempVector.rbegin();
			auto riterEnd = tempVector.rend(); 
			cout << "Expected output: ";
			for (riter; riter != riterEnd; ++riter) cout << *riter << " ";
			cout << "\n    Your output: ";
			test_printBackwards(dll1); 
			cout << endl << endl;
		}
	}
	cout << endl;
	system("Pause");
	return 0;
}


