/*
	(name header)
*/

#pragma once

#include "DArray.h"
#include "DoublyList.h"

#include <vector>
#include <list>

using namespace std;

class DArrayChild : public DArray
{
public:

	// Definition function function1
	// Your code here.


};

class DoublyListChild : public DoublyList
{
public:

	// Definition function function2
	// Your code here.



	// Definition function function3
	// Your code here.



};