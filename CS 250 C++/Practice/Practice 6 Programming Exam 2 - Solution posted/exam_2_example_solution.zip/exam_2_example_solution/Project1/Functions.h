/*
	(name header)
*/

#pragma once

#include "DArray.h"
#include "DoublyList.h"

#include <vector>
#include <list>

using namespace std;

class DArrayChild : public DArray
{
public:

	// Definition function function1
	// Your code here.
	bool function1(const vector<int>& v) const
	{
		// You should check the number of elements first,
		// because there is no need to do anything if the
		// two containers have different number of elements.
		if (numOfElem != static_cast<int>(v.size()))
			return false;
		else if (numOfElem == 0)
			return true;
		else
		{
			int idx = 0;
			while (idx < numOfElem)
			{
				if (a[idx] == v[idx])
					++idx;
				else
					return false;
			}

			return true;	
		}
	}
};

class DoublyListChild : public DoublyList
{
public:

	// Definition function function2
	// Assume both lists have at least one element.
	// May use auto.
	// Your code here.
	void function2(const list<int>& theList)
	{
		auto iter = find(theList.cbegin(), theList.cend(), first->getData());

		if (iter != theList.end())
			insertBack(*iter);
		else
			insertBack(0);
	}

	// Definition function function3
	// Assume both lists have several elements.
	// Assume DLL is empty.
	// Your code here.
	void function3(list<int>& list1, list<int>& list2)
	{
		list<int>::iterator iter = list1.begin();
		++iter;
		++iter;
		list1.splice(iter, list2, list2.begin());

		list<int>::reverse_iterator riter = list1.rbegin();
		list<int>::reverse_iterator riterEnd = list1.rend();
		for (riter; riter != riterEnd; ++riter)
			insertBack(*riter);
	}
};