/*
	(name header)
*/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <set>
#include <map>
using namespace std;

// Definition of function difference


// Definition of function multiplesOfTen


// Definition of function afterFive


#endif
