#include "HotDogStand.h"

//static variable initialized 
int HotDogStand::totalSold = 0;

HotDogStand::HotDogStand()
{
	numSold = 0;
	id = 0;
}

void HotDogStand::setID(int newID)
{
	id = newID;
}

void HotDogStand::justSold()
{
	++numSold;	
	++totalSold;    
}

int HotDogStand::getID() const
{
	return id;
}

int HotDogStand::getStandSales() const
{
	return numSold;
}

// This function was declared as static
//   but you do not need the word 
//   "static" in the definition
// Also, you cannot use modifiers such
//   as "const" for static functions
int HotDogStand::getAllSales()
{
	return totalSold;
}

HotDogStand::~HotDogStand()
{
	totalSold -= numSold;
}




