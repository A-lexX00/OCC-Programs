#ifndef HOTDOGSTAND_H
#define HOTDOGSTAND_H

#include <iostream>

using namespace std;

class HotDogStand
{
public:
	HotDogStand();

	void setID(int newID);
	
	int getID() const;
	int getStandSales() const;	

	void justSold();

	static int getAllSales();

	~HotDogStand();

private:
	static int totalSold;
	int numSold;
	int id;
};

#endif