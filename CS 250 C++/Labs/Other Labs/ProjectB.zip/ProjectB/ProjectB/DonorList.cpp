#include "DonorList.h"

DonorList::DonorList()
{
	capacity = CAP;
	list = new DonorType[capacity];
	numOfElem = 0;
}
DonorList::DonorList(int nCapacity)
{
	capacity = nCapacity;
	list = new DonorType[capacity];
	numOfElem = 0;
}
void DonorList::addDonor(string nFName, string nLName, int nMemNum, double nAmtDonated)
{
	if (capacity == numOfElem)
		resizeList();
	DonorType newDonor = DonorType(nFName, nLName, nMemNum, nAmtDonated);
	int i = 0;
	bool addedDonor = false;
	while (i < numOfElem || addedDonor)
	{
		if (newDonor.getMembershipNo() < list[i].getMembershipNo())
		{
			for (int j = i + 1; i < numOfElem; j++)
			{
				list[j] = list[i];
			}
			list[i] = newDonor;
			numOfElem++;
			addedDonor = true;
		}
		i++;
	}

}
int DonorList::getNumberOfDonors() const
{
	return numOfElem;
}
double DonorList::getTotalDonation() const
{
	double totalDonations = 0;
	for (int i = 0; i < numOfElem; i++)
	{
		totalDonations += list[i].getAmountDonated();
	}
	return totalDonations;
}
double DonorList::getHighestDonation() const
{
	double highestDonation = 0.0;
	for (int i = 0; i < numOfElem; i++)
	{
		if (highestDonation > list[i].getAmountDonated())
			highestDonation = list[i].getAmountDonated();
	}
	return highestDonation;
}
bool DonorList::isEmpty() const
{
	return numOfElem == 0;
}
bool DonorList::searchID(int nMemNum) const
{
	bool foundID = false;
	int i = 0;
	while (i < numOfElem || foundID)
	{
		if (nMemNum == list[i].getMembershipNo())
			foundID = true;
		i++;
	}
	return foundID;
}
bool DonorList::searchName(string nLName) const
{
	bool foundName = false;
	int i = 0;
	while (i < numOfElem || foundName)
	{
		if (nLName == list[i].getLastName())
			foundName = true;
		i++;
	}
	return foundName;
}
void DonorList::deleteDonor(int nMemNum) 
{
	bool deletedDonor = false;
	int i = 0;
	while (i < numOfElem || deletedDonor)
	{
		if (nMemNum = list[i].getMembershipNo())
		{
			list[i] = DonorType();
			for (int j = i + 1; i < numOfElem; j++)
			{
				list[i] = list[j];
			}
			deletedDonor = true;
			numOfElem--;
		}
		i++;
	}
}
void DonorList::emptyList() const
{
	for (int i = 0; i < numOfElem; i++)
		list[i] = DonorType();
}
void DonorList::printAllDonors() const
{
	for (int i = 0; i < numOfElem; i++)
		list[i].printDonor();
}
void DonorList::printDonorByName(string nLastName) const
{
	bool foundDonor = false;
	int i = 0;
	while (i < numOfElem || foundDonor)
	{
		if (nLastName == list[i].getLastName())
		{
			list[i].printDonor();
			foundDonor = true;
		}
		i++;
	}
	if (foundDonor)
		cerr << "There are no donors with this last name." << endl;
}
void DonorList::printDonor(int nMemNum) const
{
	bool foundDonor = false;
	int i = 0;
	while (i < numOfElem || foundDonor)
	{
		if (nMemNum == list[i].getMembershipNo())
		{
			foundDonor = true;
		}
		i++;
	}
	list[i].printDonor();
}
void DonorList::printDonation(int nMemNum) const
{
	bool foundDonor = false;
	int i = 0;
	while (i < numOfElem || foundDonor)
	{
		if (nMemNum == list[i].getMembershipNo())
		{
			foundDonor = true;
		}
		i++;
	}
	list[i].printDonation();
}
void DonorList::printTotalDonations() const
{
	cout << "Total Donations: $" << getTotalDonation() << endl;
}
void DonorList::printHighestDonation() const
{
	cout << "Highest Donation: $" << getHighestDonation() << endl;
}
DonorList::~DonorList()
{
	delete list;
	list = nullptr;
	capacity = 0;
	numOfElem = 0;
}
void DonorList::resizeList()
{

}
