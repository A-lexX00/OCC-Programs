/*
Hung, Aaron
Rabadan, Chris
Banh, Alex

CS A250
September 27, 2018

Project 1 (Part A)
*/

#include "MemberType.h"

MemberType::MemberType()
{
	membershipNumber = 0;
}
MemberType::MemberType(const string& rFirstName, const string& rLastName, int rMembershipNumber)
{
	firstName = rFirstName;
	lastName = rLastName;
	membershipNumber = rMembershipNumber;
}
void MemberType::setMemberInfo(string rFirstName, string rLastName, int rMembershipNumber)
{
	firstName = rFirstName;
	lastName = rLastName;
	membershipNumber = rMembershipNumber;
}
string MemberType::getFirstName() const
{
	return firstName;
}
string MemberType::getLastName() const
{
	return lastName;
}
int MemberType::getMembershipNo() const
{
	return membershipNumber;
}
void MemberType::printName() const
{
	cout << "    " << lastName << ", " << firstName << endl;
}
void MemberType::printMemberInfo() const
{
	cout << "    " << membershipNumber << " - " << firstName << " " << lastName << endl;
}
MemberType::~MemberType()
{

}