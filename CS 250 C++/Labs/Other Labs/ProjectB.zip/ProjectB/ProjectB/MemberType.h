/*
Hung, Aaron
Rabadan, Chris
Banh, Alex

CS A250
September 27, 2018

Project 1 (Part A)
*/

#ifndef MEMBERTYPE_H
#define MEMBERTYPE_H

#include <string>
#include <iostream>
using namespace std;

class MemberType
{
public:
	MemberType();
	MemberType(const string& firstName, const string& lastName, int membershipNumber);
	void setMemberInfo(string firstName, string lastName, int membershipNumber);
	string getFirstName() const;
	string getLastName() const;
	int getMembershipNo() const;
	void printName() const;
	void printMemberInfo() const;
	~MemberType();
private:
	string firstName;
	string lastName;
	int membershipNumber;
};

#endif