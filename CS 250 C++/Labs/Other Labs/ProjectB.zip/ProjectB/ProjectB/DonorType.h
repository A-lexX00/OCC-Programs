#ifndef DONORTYPE_H
#define DONORTYPE_H

#include <iostream>
#include <string>
#include "MemberType.h"

using namespace std;

class DonorType : public MemberType
{
public:
	DonorType();
	DonorType(string firstName, string lastName,
				int membershipNumber, double dAmount);

	void setDonorInfo(string rFirstName, string rLastName,
		int rMembershipNumber, double dAmount);
	void setAmountDonated(double dAmount);
	double getAmountDonated() const;

	void printDonor() const;
	void printDonation() const;

	~DonorType();
private:
	double dAmount;
};

#endif