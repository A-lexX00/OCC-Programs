#ifndef DONORLIST_H
#define DONORLIST_H

#include "DonorType.h"

#include<iostream>
#include <string>		
#include <iomanip>

using namespace std;

const int CAP = 20;

class DonorList
{
public:
	
	// Declarations public member functions
	DonorList();
	DonorList(int capacity);
	void addDonor(string fName, string lName, int memNum, double amtDonated);
	int getNumberOfDonors() const;
	double getTotalDonation() const;
	double getHighestDonation() const;
	bool isEmpty() const;
	bool searchID(int memNum) const;
	bool searchName(string lName) const;
	void deleteDonor(int memNum);
	void emptyList() const;
	void printAllDonors() const;
	void printDonorByName(string lName) const;
	void printDonor(int memNum) const;
	void printDonation(int memNum) const;
	void printTotalDonations() const;
	void printHighestDonation() const;
	~DonorList();

private:

	// Declaration private member function
	void resizeList();
	DonorType *list;
	int capacity;
	int numOfElem;		
};

#endif

