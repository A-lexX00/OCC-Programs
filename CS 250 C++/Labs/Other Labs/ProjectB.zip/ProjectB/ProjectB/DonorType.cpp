#include "DonorType.h"
#include <iomanip>

DonorType::DonorType() 
{
	dAmount = 0.00;
}
DonorType::DonorType(string rFirstName, string rLastName,
	int rMembershipNumber, double rdAmount)
	: MemberType(rFirstName, rLastName, rMembershipNumber)
{
	dAmount = rdAmount;
}

void DonorType::setDonorInfo(string rFirstName, string rLastName,
	int rMembershipNumber, double rDAmount)
{
	setMemberInfo(rFirstName, rLastName, rMembershipNumber);
	dAmount = rDAmount;
}
void DonorType::setAmountDonated(double rDAmount)
{
	dAmount = rDAmount;
}
double DonorType::getAmountDonated() const
{
	return dAmount;
}

void DonorType::printDonor() const
{
	printMemberInfo();
}

void DonorType::printDonation() const
{
	cout << getLastName() << ", " << getFirstName() << endl;
	cout << "    Donation amount: $" << fixed << dAmount << setprecision(2);
}

DonorType::~DonorType()
{

}