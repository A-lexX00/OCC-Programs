/*
(name header)
*/

#include "DPair.h"

ostream& operator<<(ostream& out, const DPair& pair)
{
	out << "(" << *pair.first << ", " << *pair.second << ")";
	return out;
}

DPair::DPair()
{
	first = new int;
	second = new int;
	*first = 0;
	*second = 0;
}

DPair::DPair(int newFirst, int newSecond)
{
	first = new int;
	second = new int;
	*first = newFirst;
	*second = newSecond;
}

DPair::DPair(const DPair& otherPair)
{
	first = new int; 
	second = new int; 
	*first = *(otherPair.first);
	*second = *(otherPair.second);
}

void DPair::setFirst(int newFirst) const
{
	*first = newFirst;
}

void DPair::setSecond(int newSecond) const
{
	*second = newSecond;
}

DPair& DPair::operator=(const DPair& otherPair)
{
	if (&otherPair != this)
	{
		*first = *(otherPair.first);
		*second = *(otherPair.second);
	}
	else
		cerr << "Attempted assignment to itself." << endl;

	return *this;
}

DPair::~DPair()
{
	delete first;
	delete second;
	first = nullptr;
	second = nullptr;
}