/*
	(name header)
*/

#ifndef DPAIR_H
#define DPAIR_H

#include <iostream>
#include <string>

using namespace std;

class DPair
{
	friend ostream& operator<<(ostream& out, const DPair& pair);

public:
	DPair();
	DPair(int newFirst, int newSecond);
	DPair(const DPair& otherPair);

	void setFirst(int newFirst) const;
	void setSecond(int newSecond) const;
	// Why are these mutator functions const?

	DPair& operator=(const DPair& otherPair);

	~DPair();

private:
	int *first,
		*second;
};
#endif
