/*
	(name header)
*/

#include "AnyList.h"

// Definition of function deleteNode
void AnyList::deleteNode(int deleteData)
{
	// Write your code here...

}