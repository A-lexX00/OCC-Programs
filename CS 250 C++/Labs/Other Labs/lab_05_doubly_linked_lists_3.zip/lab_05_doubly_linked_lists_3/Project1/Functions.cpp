/*
	Name header
*/

#include "DoublyList.h"

// Definition function print


// Definition function reversePrint


// Definition function front


// Definition function back


// Definition function copyToList
// Copies from parameter object to empty calling object


// Definition function deleteElem
