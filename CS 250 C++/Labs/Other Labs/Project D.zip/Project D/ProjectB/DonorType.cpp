/*
BackAtItAgain

Hung, Aaron
Banh, Alex

CS A250
December 1, 2018

Project 2 (Part B)
*/

#include "DonorType.h"

DonorType::DonorType() 
{
	amtDonated = 0.0;
}

DonorType::DonorType(const string& rFirstName, 
	const string& rLastName, int rMembershipNumber, 
	double rAmtDonated)
	: MemberType(rFirstName, rLastName, rMembershipNumber)
{
	amtDonated = rAmtDonated;
}

void DonorType::setDonorInfo(const string& rFirstName, 
	const string& rLastName, int rMembershipNumber, 
	double rAmtDonated)
{
	setMemberInfo(rFirstName, rLastName, rMembershipNumber);
	amtDonated = rAmtDonated;
}

void DonorType::setAmountDonated(double rAmtDonated)
{
	amtDonated = rAmtDonated;
}

double DonorType::getAmountDonated() const
{
	return amtDonated;
}

void DonorType::printDonor() const
{
	printMemberInfo();
}

void DonorType::printDonation() const
{
	cout << "     " << getLastName() << ", " 
		<< getFirstName() << endl;
	cout << "     Donation amount: $" << amtDonated << endl;
}

bool DonorType::operator==(const DonorType& rightSide) const
{
	return (getMembershipNo() == rightSide.getMembershipNo());
}

DonorType::~DonorType()
{

}