/*
BackAtItAgain

Hung, Aaron
Banh, Alex

CS A250
December 1, 2018

Project 2 (Part B)
*/

#ifndef DONORTYPE_H
#define DONORTYPE_H

#include "MemberType.h"

#include <iostream>
#include <string>

using namespace std;

class DonorType : public MemberType
{
public:
	DonorType();
	DonorType(const string& fName, const string& lName,
				int memNumber, double amtDonated);

	void setDonorInfo(const string& rFName, 
		const string& rLName, int rMemNumber, double amtDonated);
	void setAmountDonated(double amtDonated);

	double getAmountDonated() const;

	void printDonor() const;
	void printDonation() const;

	bool operator==(const DonorType& rightSide) const;

	~DonorType();

private:
	double amtDonated;
};

#endif