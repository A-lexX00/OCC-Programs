/*
BackAtItAgain

Hung, Aaron
Banh, Alex

CS A250
December 1, 2018

Project 2 (Part B)
*/

#include "MemberType.h"

MemberType::MemberType()
{
	memNumber = 0;
}

MemberType::MemberType(const string& rFName, 
	const string& rLName, int rMemNumber)
{
	fName = rFName;
	lName = rLName;
	memNumber = rMemNumber;
}

void MemberType::setMemberInfo(const string& rFName, 
	const string& rLName, int rMemNumber)
{
	fName = rFName;
	lName = rLName;
	memNumber = rMemNumber;
}

string MemberType::getFirstName() const
{
	return fName;
}

string MemberType::getLastName() const
{
	return lName;
}

int MemberType::getMembershipNo() const
{
	return memNumber;
}

void MemberType::printName() const
{
	cout << "     " << lName << ", " << 
		fName << endl;
}

void MemberType::printMemberInfo() const
{
	cout << "     " << memNumber << " - " 
		<< fName << " " << lName << endl;
}

MemberType::~MemberType()
{

}