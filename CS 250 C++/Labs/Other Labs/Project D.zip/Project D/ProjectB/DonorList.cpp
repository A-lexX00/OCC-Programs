/*
BackAtItAgain

Hung, Aaron
Banh, Alex

CS A250
December 1, 2018

Project 2 (Part B)
*/

#include "DonorList.h"

DonorList::DonorList()
{
	donors = new list<DonorType>;
}

DonorList::DonorList(const DonorList& otherDList)
{
	donors = new list<DonorType>;

	donors->assign(otherDList.donors->cbegin(),
		otherDList.donors->cend());
}

DonorList& DonorList::operator=(const DonorList& rightSide)
{
	if (&rightSide != this)
		donors->assign(rightSide.donors->cbegin(), 
			rightSide.donors->cend());
	else
		cerr << "Cannot assign to itself.";

	return *this;
}

void DonorList::addDonor(const string& nFName, 
	const string& nLName, int nMemNum, double nAmtDonated)
{
	DonorType newDonor = 
		DonorType(nFName, nLName, nMemNum, nAmtDonated);

	if (donors->size() == 0)
		donors->push_back(newDonor);
	else if ((donors->rbegin())->getMembershipNo() 
				< newDonor.getMembershipNo())
		donors->push_back(newDonor);
	else
	{
		list<DonorType>::iterator iter = donors->begin();
		list<DonorType>::iterator endIter = donors->end();

		bool addedDonor = false;

		while (!addedDonor)
		{
			if (iter->getMembershipNo() 
				> newDonor.getMembershipNo())
			{
				donors->insert(iter, newDonor);
				addedDonor = true;
			}
			iter++;
		}
	}
}

int DonorList::getNumberOfDonors() const
{
	return donors->size();
}

double DonorList::getTotalDonation() const
{
	double totalDonations = 0;

	list<DonorType>::const_iterator iter = donors->cbegin();
	list<DonorType>::const_iterator endIter = donors->cend();

	while(iter != endIter)
	{
		totalDonations += iter->getAmountDonated();
		iter++;
	}
	return totalDonations;
}

double DonorList::getHighestDonation() const
{
	double highestDonation = 0.0;

	list<DonorType>::const_iterator iter = donors->cbegin();
	list<DonorType>::const_iterator endIter = donors->cend();

	while (iter != endIter)
	{
		if (highestDonation < iter->getAmountDonated())
			highestDonation = iter->getAmountDonated();
		iter++;
	}
	return highestDonation;
}

bool DonorList::isEmpty() const
{
	return donors->size() == 0;
}

bool DonorList::searchID(int nMemNum) const
{
	list<DonorType>::const_iterator iter = donors->cbegin();
	list<DonorType>::const_iterator endIter = donors->cend();
	DonorType dt(" ", " ", nMemNum, 0.0);
	list<DonorType>::const_iterator foundItem
		= find(iter, endIter, dt);

	return (foundItem != endIter);
}

void DonorList::deleteDonor(int nMemNum)
{
	list<DonorType>::iterator iter = donors->begin();
	list<DonorType>::iterator endIter = donors->end();
	DonorType dt(" ", " ", nMemNum, 0.0);
	list<DonorType>::iterator foundItem
		= find(iter, endIter, dt);

	donors->erase(foundItem);
}

void DonorList::emptyList()  
{
	delete donors;
	donors = nullptr;
}

void DonorList::printAllDonors() const
{
	list<DonorType>::const_iterator iter = donors->cbegin();

	while (iter != donors->cend())
	{
		iter->printDonor();
		iter++;
	}
}

void DonorList::printDonorByName(const string& nLastName) const
{
	list<DonorType>::const_iterator iter = donors->cbegin();

	bool foundDonor = false;
	
	while (iter != donors->cend() || !foundDonor)
	{
		if (nLastName == iter->getLastName())
		{
			iter->printDonor();
			foundDonor = true;
		}
		iter++;
	}
	if (!foundDonor)
		cout << "There are no donors with this last name." << endl;
}

void DonorList::printDonor(int nMemNum) const
{
	list<DonorType>::const_iterator iter = donors->cbegin();
	list<DonorType>::const_iterator iterEnd = donors->cend();
	DonorType dt(" ", " ", nMemNum, 0.0);
	list<DonorType>::const_iterator foundItem
		= find(iter, iterEnd, dt);

	foundItem->DonorType::printDonor();
}

void DonorList::printDonation(int nMemNum) const
{
	list<DonorType>::const_iterator iter = donors->cbegin();
	list<DonorType>::const_iterator iterEnd = donors->cend();
	DonorType dt(" ", " ", nMemNum, 0.0);
	list<DonorType>::const_iterator foundItem
		= find(iter, iterEnd, dt);

	foundItem->DonorType::printDonation();
}

void DonorList::printTotalDonations() const
{
	cout << "     Total Donations: $" 
		<< getTotalDonation() << endl;
}

void DonorList::printHighestDonation() const
{
	cout << "     Highest Donation: $" 
		<< getHighestDonation() << endl;
}

DonorList::~DonorList()
{
	emptyList();
}
