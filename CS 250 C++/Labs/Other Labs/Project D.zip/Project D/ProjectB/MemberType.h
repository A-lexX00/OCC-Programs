/*
BackAtItAgain

Hung, Aaron
Banh, Alex

CS A250
December 1, 2018

Project 2 (Part B)
*/

#ifndef MEMBERTYPE_H
#define MEMBERTYPE_H

#include <string>
#include <iostream>

using namespace std;

class MemberType
{
public:

	MemberType();
	MemberType(const string& fName, 
		const string& lName, int memNumber);
	
	void setMemberInfo(const string& fName, 
		const string& lName, int memNumber);
	
	string getFirstName() const;
	string getLastName() const;
	int getMembershipNo() const;
	
	void printName() const;
	void printMemberInfo() const;
	
	~MemberType();

private:

	string fName;

	string lName;

	int memNumber;

};

#endif