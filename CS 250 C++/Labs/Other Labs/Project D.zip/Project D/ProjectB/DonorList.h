/*
BackAtItAgain

Hung, Aaron
Banh, Alex

CS A250
December 1, 2018

Project 2 (Part B)
*/

#ifndef DONORLIST_H
#define DONORLIST_H

#include "DonorType.h"

#include <iostream>
#include <string>
#include <list>
#include <algorithm>

using namespace std;

class DonorList
{
public:
	DonorList();
	DonorList(const DonorList& otherDList);

	DonorList& operator=(const DonorList& rightSide);

	void addDonor(const string& fName, const string& lName,
		int memNum, double amtDonated);
	
	int getNumberOfDonors() const;
	double getTotalDonation() const;
	double getHighestDonation() const;
	
	bool isEmpty() const;
	
	bool searchID(int memNum) const;
	
	void deleteDonor(int memNum);
	void emptyList();
	
	void printAllDonors() const;
	void printDonorByName(const string& lName) const;
	void printDonor(int memNum) const;
	void printDonation(int memNum) const;
	void printTotalDonations() const;
	void printHighestDonation() const;
	
	~DonorList();

private:

	list<DonorType> * donors;

};

#endif

