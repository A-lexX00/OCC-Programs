/*
	(name header)
*/

#ifndef POKEMON_H
#define POKEMON_H

#include <iostream>
#include <string>

using namespace std;

class Pokemon
{
public:
	Pokemon();
	Pokemon(const string& newName, int newNumber,
		const string& newType1);
	Pokemon(const string& newName, int newNumber,
		const string& newType1, const string& newType2);
	
	string  getType1() const;
	string  getType2() const;

	bool commonType(const Pokemon& otherPokemon) const;

	void print() const;

	~Pokemon();

private:
	string name;
	int number;
	string type1;
	string type2;
};

#endif // POKEMON_H
