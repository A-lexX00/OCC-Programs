#include "DArray.h"

ostream& operator<<(ostream& out, const DArray& arr)
{
	//Assume array is non-empty.

	for (int i = 0; i < arr.numOfElem; ++i)
		out << arr.a[i] << " ";

	return out;
}

DArray::DArray( )
{
    capacity = CAP;
	a = new int[capacity];	
	numOfElem = 0;
}

DArray::DArray(int newCapacity) 
{
	capacity = newCapacity;
    a = new int[capacity];
	numOfElem = 0;	 
}

DArray::DArray(const DArray& otherArray)
{
	capacity = otherArray.capacity;	
	a = new int[capacity];
	numOfElem = otherArray.numOfElem;

	for (int i = 0; i < numOfElem; ++i)
		a[i] = otherArray.a[i];
}

void DArray::addElement(int element) 
{
	a[numOfElem] = element;
    ++numOfElem;
}


int DArray::getCapacity() const
{
	return capacity;
}

int DArray::getNumOfElem() const
{
	return numOfElem;
}

int& DArray::operator[](int idx) const
{
	return a[idx];
}

DArray& DArray::operator=(const DArray& otherArray)
{
	if (&otherArray != this)
	{
		if (capacity != otherArray.capacity)
		{
			delete[] a; //release space
			a = new int[otherArray.capacity];
			capacity = otherArray.capacity;
		}
		for (int i = 0; i < otherArray.numOfElem; ++i)
			a[i] = otherArray.a[i];
		numOfElem = otherArray.numOfElem;
	}
	else
		cerr << "Attempted assignment to itself.";

	return *this;
}

DArray::~DArray( )
{
    delete [] a;
	a = nullptr;	
}

//*******************************************************************

// Definition deleteElement
// Your code here...



// Definition search
// Your code here...



// Definition emptyArray
// Your code here...



// Definition isEmpty
// Your code here...



// Definition isFull
// Your code here...

