/*
	Nguyen, Da

	CS A250
	April 21, 2018

	Lab 10
*/

#ifndef MOVIE_H
#define MOVIE_H

#include <iostream>
#include<string>
using namespace std;

class Movie
{
	// Overloaded insertion operator (<<)
	friend ostream& operator<<(ostream& out, const Movie& movie);

public:
	// Constructor
	Movie( );
	// Overloaded constructor
	Movie(const string&, int);

	// Accessor functions
	string getTitle() const;
	int getYear() const;

	// Mutator functions
	void setTitle(const string&);
	void setYear(int);

	// Overloaded comparison operator (==)
	bool operator==(const Movie& otherMovie) const;

	// Destructor
	~Movie( );

private:
	string title;
	int year;

};

#endif