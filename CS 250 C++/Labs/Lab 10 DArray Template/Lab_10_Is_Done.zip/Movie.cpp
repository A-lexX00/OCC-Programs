/*
	Nguyen, Da

	CS A250
	April 21, 2018

	Lab 10
*/

#include "Movie.h"

// Overloaded insertion operator (<<)
ostream& operator<<(ostream& out, const Movie& movie)
{
	out << "\"" << movie.title << "\" (" << movie.year << ")\n";

	return out;
}

// Constructor
Movie::Movie(): year(0) { }

// Overloaded constructor
Movie::Movie(const string& newTitle, int newYear)
{
	title = newTitle;
	year = newYear;
}

// Accessor functions
string Movie::getTitle() const
{
	return title;
}

int Movie::getYear() const
{
	return year;
}

// Mutator functions
void Movie::setTitle(const string& newTitle)
{
	title = newTitle;
}

void Movie::setYear(int newYear)
{
	year = newYear;
}

// Overloaded comparison operator (==)
bool Movie::operator==(const Movie& otherMovie) const
{
	return (title == otherMovie.title && year == otherMovie.year);
}

// Destructor
Movie::~Movie() { }