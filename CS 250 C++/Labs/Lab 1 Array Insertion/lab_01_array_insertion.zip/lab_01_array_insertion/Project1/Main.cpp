/*
	(name header)
*/

#include <iostream>
using namespace std;

const int CAPACITY = 10;

// Declaration function insertAtIndex
// Your code here...

#include "Testing.hxx"

int main( )
{
	testCases();

	cout << endl;
	system("Pause");
    return 0;
}

// Definition function insertAtIndex
// Your code here...
