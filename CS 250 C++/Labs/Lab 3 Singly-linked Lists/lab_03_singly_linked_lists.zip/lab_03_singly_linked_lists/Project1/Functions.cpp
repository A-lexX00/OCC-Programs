/*
	(name header)
*/

#include "AnyList.h"

//Declaration function search


//Definition function commonEnds

