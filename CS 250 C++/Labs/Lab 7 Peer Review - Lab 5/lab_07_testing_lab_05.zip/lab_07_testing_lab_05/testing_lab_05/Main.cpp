/***********************************************

	Class DoublyList

************************************************/

#include "DoublyList.h"

#include <iostream>
using namespace std;

int main()
{
	DoublyList myList;

	cout << "TEST: List is empty. Insert 3...\n";
	myList.insertInOrder(3);
	cout << "\nPrint forward:\n\t=> Expected: 3 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 3 => Output:  ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 1 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 3 => Output: " 
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 3 => Output: " 
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: " 
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: " 
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 2...\n";
	myList.insertInOrder(2);
	cout << "\nPrint forward:\n\t=> Expected: 2 3 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 3 2 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 2 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 2 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 3 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 6...\n";
	myList.insertInOrder(6);
	cout << "\nPrint forward:\n\t=> Expected: 2 3 6 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 6 3 2 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 3 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 2 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 6 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 8...\n";
	myList.insertInOrder(8);
	cout << "\nPrint forward:\n\t=> Expected: 2 3 6 8 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 8 6 3 2 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 4 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 2 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 8 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 7...\n";
	myList.insertInOrder(7);
	cout << "\nPrint forward:\n\t=> Expected: 2 3 6 7 8 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 8 7 6 3 2 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 5 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 2 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 8 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 5...\n";
	myList.insertInOrder(5);
	cout << "\nPrint forward:\n\t=> Expected: 2 3 5 6 7 8 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 8 7 6 5 3 2 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 6 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 2 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 8 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "Destroy list to start all over...";
	myList.destroyList();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 4...\n";
	myList.insertInOrder(4);
	cout << "\nPrint forward:\n\t=> Expected: 4 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 4 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 1 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 4 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 4 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << "\n\n---------------------------------------------------------\n\n";

	cout << "TEST: Insert 8...\n";
	myList.insertInOrder(8);
	cout << "\nPrint forward:\n\t=> Expected: 4 8 => Output: ";
	myList.print();
	cout << "\nPrint backwards:\n\t=> Expected: 8 4 => Output: ";
	myList.reversePrint();
	cout << "\nCount:\n\t=> Expected: 2 => Output: "
		<< myList.getCount();
	cout << "\nValue in first node:\n\t=> Expected: 4 => Output: "
		<< myList.front();
	cout << "\nValue in last node:\n\t=> Expected: 8 => Output: "
		<< myList.back();
	cout << "\nPrevious pointer of first node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrPrevOfFirst();
	cout << "\nNext pointer of last node:\n\t=> Expected: 0...0 => Output: "
		<< myList.getPtrNextOfLast();

	cout << endl << endl;
	system("Pause");
	return 0;
}
