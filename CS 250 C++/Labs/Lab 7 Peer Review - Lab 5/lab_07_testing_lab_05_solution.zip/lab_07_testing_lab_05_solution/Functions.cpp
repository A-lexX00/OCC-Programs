/*
	Name header
*/

#include "DoublyList.h"

// Definition function print
void DoublyList::print() const
{
	Node *current = first;; //set pointer current to point to the first node

	while (current != nullptr)
	{
		cout << current->getData() << " ";  //output info
		current = current->getNext();
	}
}

// Definition function reversePrint
void DoublyList::reversePrint() const
{
	Node *current = last;  //set pointer current to point to the last node

	while (current != nullptr)
	{
		cout << current->getData() << " ";
		current = current->getPrev();
	}
}

// Definition function front
int DoublyList::front() const
{
	return first->getData();
}

// Definition function back
int DoublyList::back() const
{
	return last->getData();
}

// Definition function copyToList
void DoublyList::copyToList(DoublyList& otherList) const
{
	Node *temp = last;
			
	while (temp != nullptr)
	{
		otherList.insertFront(temp->getData());
		temp = temp->getPrev();
	}
}

// Definition function insertInOrder 
void DoublyList::insertInOrder(int insertItem)
{
	//if the list is empty or if the node needs to be inserted
	//before the first node, we can use function insertFront
	if (first == nullptr || insertItem < first->getData())
	{
		insertFront(insertItem);

		//no need to increment the count, because function insertFront will do it
	}
	//else the new node needs to be inserted somewhere after the first node
	else
	{
		Node *newNode = new Node(insertItem, nullptr, nullptr);

		// check last node
		if (last->getData() < insertItem)
		{
			last->setNext(newNode);
			newNode->setPrev(last);
			last = newNode;
			++count;
		}
		else // insert somewhere in the middle
		{
			Node *current = first->getNext();    //pointer to traverse the list
			bool found = false;

			while (current != nullptr && !found) //search the list
			{
				if (current->getData() >= insertItem)
				{
					newNode->setPrev(current->getPrev());
					newNode->setNext(current);
					current->getPrev()->setNext(newNode);
					current->setPrev(newNode);
					found = true;
					++count;
				}
				else
					current = current->getNext();
			}
		}
	}
}