/*
	CodeLovers
	
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	May 13, 2018

	Project 2B
*/

#include "PersonType.h"

// Default constructor
PersonType::PersonType() : ssn(0) { }

// Overloaded constructor
PersonType::PersonType(const string& nFirstName, const string& nLastName, int newSSN)
{
	firstName = nFirstName;
	lastName = nLastName;
	ssn = newSSN;
}

// Function setPersonInfo
void PersonType::setPersonInfo(const string& nFirstName, const string& nLastName, int newSSN)
{
	firstName = nFirstName;
	lastName = nLastName;
	ssn = newSSN;
}

// Function getFirstName
string PersonType::getFirstName() const
{
	return firstName;
}

// Function getLastName
string PersonType::getLastName() const
{
	return lastName;
}

// Function getSSN
int PersonType::getSSN() const
{
	return ssn;
}

// Function printName
void PersonType::printName() const
{
	cout << lastName << ", " << firstName;
}

// Function printPersonInfo
void PersonType::printPersonInfo() const
{
	printSSN();

	cout << lastName << ", " << firstName;
}

// Function printSSN
void PersonType::printSSN() const
{
	cout << (ssn / 1000000) << "-";
	cout << (ssn % 1000000 / 10000) << "-";
	cout << (ssn % 10000) << " - ";
}

// Destructor
PersonType::~PersonType() { }
