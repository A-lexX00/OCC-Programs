/*
	CodeLovers
	
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	May 13, 2018

	Project 2B
*/

#include "CandidateType.h"

// Default constructor
CandidateType::CandidateType()
{
	totalNumOfVotes = 0;

	for (int i = 0; i < NUM_OF_DIVISIONS; ++i)
	{
		votes[i] = 0;
	}	
}

// Function updateVotesByDivision
void CandidateType::updateVotesByDivision(int divisionNum, int numOfVotes)
{
	votes[divisionNum] = numOfVotes;
	totalNumOfVotes += numOfVotes;
}

// Function getTotalVotes
int CandidateType::getTotalVotes() const
{
	return totalNumOfVotes;
}

// Funtion getVotesByDivision
int CandidateType::getVotesByDivision(int divisionNum) const
{
	return votes[divisionNum - 1];
}

// Function printCandidateInfo
void CandidateType::printCandidateInfo() const
{
	if(getFirstName() == "" || getLastName() == "" || getSSN() == 0)
		cout << "No information available for this candidate.";
	else
	{
		printSSN();
		printName();
	}		
}

// Function printCandidateTotalVotes
void CandidateType::printCandidateTotalVotes() const
{
	printName();
	cout << "    => Total votes: " << getTotalVotes();
}

// Function printCandidateDivisionVotes
void CandidateType::printCandidateDivisionVotes(int divisionNum) const
{
	printName();
	cout << "    => Division " << divisionNum << " Total votes: "
		 << votes[divisionNum - 1];
}

// Destructor
CandidateType::~CandidateType() { }