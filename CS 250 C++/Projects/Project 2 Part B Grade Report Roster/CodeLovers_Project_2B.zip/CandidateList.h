/*
	CodeLovers

	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	May 13, 2018

	Project 2B
*/

#ifndef CANDIDATELIST_H
#define CANDIDATELIST_H

#include "CandidateType.h"

#include <iostream>
#include <string>
#include<iomanip>
#include<vector>

using namespace std;

class CandidateList
{
public:
	// Default constructor
	CandidateList();

	// Copy constructor
	CandidateList(const CandidateList& otherCandidateList);

	// Overloaded assignment operator
	CandidateList& operator=(const CandidateList& rightSide);

	// Function addCandidate
	void addCandidate(const CandidateType& newCandidate) const;

	// Function getWinner
	int getWinner() const;

	// Function searchCandidate
	bool searchCandidate(int sSNum) const;

	// Function isEmpty
	bool isEmpty() const;

	// Function printCandidateName
	void printCandidateName(int sSNum) const;

	// Function printAllCandidates
	void printAllCandidates() const;

	// Function printCandidateDivisionVotes
	void printCandidateDivisionVotes(int sSNum, int divisionNum) const;

	// Function printCandidateTotalVotes
	void printCandidateTotalVotes(int sSNum) const;	

	// Function deleteCandidates
	void deleteCandidates();

	// Destructor
	~CandidateList();

private:
	// Private overloaded function searchCandidate
	bool searchCandidate(int sSNum, vector<CandidateType>::const_iterator& it) const
	{
		it = candidates->cbegin();

		while (it != candidates->cend())
		{
			if (it->getSSN() == sSNum)
				return true;	// Return true if SSN is found.
			else
				it++;
		}

		// Print the message if SSN is not found.
		cerr << "    => SSN not found." << endl;

		return false;
	}

	vector<CandidateType> *candidates;	// candidates as a pointer
};

#endif