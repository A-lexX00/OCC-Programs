/*
	CodeLovers
	
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	May 13, 2018

	Project 2B
*/

#ifndef PERSONTYPE_H
#define PERSONTYPE_H

#include <iostream>
#include <string>

using namespace std;

class PersonType
{
public:
	// Default constructor
	PersonType();

	// Overloaded constructor
	PersonType(const string& nFirstName, const string& nLastName,int newSSN);

	// Function setPersonInfo
	void setPersonInfo(const string& nFirstName, const string& nLastName, int newSSN);

	// Function getFirstName
	string getFirstName() const;

	// Function getLastName
	string getLastName() const;

	// Function getSSN
	int getSSN() const;

	// Function printName
	void printName() const;

	// Function printPersonInfo
	void printPersonInfo() const;

	// Function printSSN
	void printSSN() const;	

	// Destructor
	~PersonType();

private:
	string firstName;
	string lastName;
	int ssn;
};

#endif