/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 10, 2018

	Project 1_B
*/

#ifndef PERSONTYPE_H
#define PERSONTYPE_H

#include <iostream>
#include <string>

using namespace std;

class PersonType
{
public:

	// default constructor
	PersonType();

	// overloaded constructor
	PersonType(const string& nFirstName, const string& nLastName,int newSSN);

	// function setPersonInfo
	void setPersonInfo(const string& nFirstName, const string& nLastName, int newSSN);

	// function getFirstName
	string getFirstName() const;

	// function getLastName
	string getLastName() const;

	// function getSSN
	int getSSN() const;

	// printName
	void printName() const;

	// function printSSN
	void printSSN() const;

	// function printPersonInfo
	void printPersonInfo() const;

	// destructor
	~PersonType();

private:
	string firstName;
	string lastName;
	int ssn;
};

#endif