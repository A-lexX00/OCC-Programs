/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 10, 2018

	Project 1_B
*/

#ifndef CANDIDATETYPE_H
#define CANDIDATETYPE_H

#include "PersonType.h"

#include <iostream>
#include <string>

using namespace std;

//Global constant
const int NUM_OF_DIVISIONS = 4;

class CandidateType : public PersonType
{
public:
	//default constructor
	CandidateType();

	//function updateVotesByDivision
	void updateVotesByDivision(int divisionNum, int numOfVotes);

	//function getTotalVotes
	int getTotalVotes() const;

	//funtion getVotesByDivision
	int getVotesByDivision(int divisionNum) const;

	//function printCandidateInfo
	void printCandidateInfo() const;

	//function printCandidateTotalVotes
	void printCandidateTotalVotes() const;

	//function printCandidateDivisionVotes
	void printCandidateDivisionVotes(int divisionNum) const;

	//destructor
	~CandidateType();

private:
	int totalNumOfVotes;
	int votes[NUM_OF_DIVISIONS];
};

#endif
