/*
	CodeLovers

	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	May 06, 2018

	Project 2A
*/

#include "CandidateList.h"

// Default constructor
CandidateList::CandidateList() { }

// Function addCandidate
void CandidateList::addCandidate(const CandidateType& newCandidate)
{	
	candidates.push_back(newCandidate);
}

// Function getWinner
int CandidateList::getWinner() const
{
	vector<CandidateType>::const_iterator it = candidates.cbegin();	
	int highestNumOfVotes = it->getTotalVotes();
	int ssn = it->getSSN();
	it++;

	while (it != candidates.cend())
	{
		if (highestNumOfVotes < it->getTotalVotes())
		{
			highestNumOfVotes = it->getTotalVotes();
			ssn = it->getSSN();
		}	
			
		it++;
	}

	return ssn;
}

// Function searchCandidate
bool CandidateList::searchCandidate(int sSNum) const
{	
	vector<CandidateType>::const_iterator it = candidates.cbegin();

	return searchCandidate(sSNum, it);
}

// Function isEmpty
bool CandidateList::isEmpty() const
{
	return (candidates.cbegin() == candidates.cend());
}

// Function printCandidateName
void CandidateList::printCandidateName(int sSNum) const
{	
	vector<CandidateType>::const_iterator it = candidates.cbegin();
	
	if (searchCandidate(sSNum, it))
		it->printName();
}

// Function printAllCandidates
void CandidateList::printAllCandidates() const
{
	vector<CandidateType>::const_iterator it = candidates.cbegin();

	while (it != candidates.cend())
	{
		it->printCandidateInfo();
		cout << endl;
		it++;
	}
}

// Function printCandidateDivisionVotes
void CandidateList::printCandidateDivisionVotes(int sSNum, int divisionNum) const
{	
	vector<CandidateType>::const_iterator it = candidates.cbegin();

	if (searchCandidate(sSNum, it))
		cout << "    => Division " << divisionNum << ": "
			 << it->getVotesByDivision(divisionNum) << endl;
}

// Function printCandidateTotalVotes
void CandidateList::printCandidateTotalVotes(int sSNum) const
{
	vector<CandidateType>::const_iterator it = candidates.cbegin();

	if (searchCandidate(sSNum, it))
		cout << "    => Total votes: " 
			 << it->getTotalVotes() << endl;
}

// Destructor
CandidateList::~CandidateList() { }