/*
	CodeLovers

	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	May 06, 2018

	Project 2A
*/

#ifndef CANDIDATETYPE_H
#define CANDIDATETYPE_H

#include "PersonType.h"

#include <iostream>
#include <string>

using namespace std;

//Global constant
const int NUM_OF_DIVISIONS = 4;

class CandidateType : public PersonType
{
public:
	// Default constructor
	CandidateType();

	// Function updateVotesByDivision
	void updateVotesByDivision(int divisionNum, int numOfVotes);

	// Function getTotalVotes
	int getTotalVotes() const;

	// Funtion getVotesByDivision
	int getVotesByDivision(int divisionNum) const;

	// Function printCandidateInfo
	void printCandidateInfo() const;

	// Function printCandidateTotalVotes
	void printCandidateTotalVotes() const;

	// Function printCandidateDivisionVotes
	void printCandidateDivisionVotes(int divisionNum) const;

	// Destructor
	~CandidateType();

private:
	int totalNumOfVotes;
	int votes[NUM_OF_DIVISIONS];
};

#endif
