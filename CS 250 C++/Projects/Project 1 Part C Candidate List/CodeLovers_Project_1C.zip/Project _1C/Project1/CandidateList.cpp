/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 17, 2018

	Project 1C
*/

#include "CandidateList.h"

// default constructor
CandidateList::CandidateList() : first(nullptr), last(nullptr), count(0) {}

// addCandidate
void CandidateList::addCandidate(const CandidateType& newCandidate)
{	
	if (count == 0)
	{
		first = new Node(newCandidate, nullptr);
		last = first;
	}
	else
	{
		last->setLink(new Node(newCandidate, nullptr));
		last = last->getLink();
	}

	count++;
}

// getWinner
int CandidateList::getWinner() const
{	
	if (first == nullptr)
	{
		cerr << "     => List is empty." << endl;
		return 0;
	}		
	else
	{
		Node *current = first;
		int highestNumOfVotes = first->getCandidate().getTotalVotes();	
		int ssn = first->getCandidate().getSSN();
		current = current->getLink();

		while (current != nullptr)
		{		
			if (highestNumOfVotes < current->getCandidate().getTotalVotes())
			{
				highestNumOfVotes = current->getCandidate().getTotalVotes();
				ssn = current->getCandidate().getSSN();
			}	
			
			current = current->getLink();
		}

		return ssn;
	}		
}

// searchCandidate
bool CandidateList::searchCandidate(int sSNum)
{	
	if (first == nullptr)
		cerr << "     => List is empty." << endl;
	else
	{
		Node *current = first;
		bool isFound = false;

		while (current != nullptr && !isFound)
		{
			if (current->getCandidate().getSSN() == sSNum)
			{
				isFound = true;
				return true;
			}							
			else
				current = current->getLink();
		}

		if (!isFound)
			cerr << "    => SSN not in the list." << endl;		
	}	

	return false;
}

// printCandidateName
void CandidateList::printCandidateName(int sSNum) const
{	
	if (first == nullptr)
		cerr << "     => List is empty." << endl;
	else
	{
		Node *current = first;
		bool isFound = false;

		while (current != nullptr && !isFound)
		{
			if (current->getCandidate().getSSN() == sSNum)
			{
				current->getCandidate().printName();
				isFound = true;				
			}				
			else
				current = current->getLink();
		}

		if (!isFound)
			cerr << "    => SSN not in the list." << endl;
	}
}

// printAllCandidates
void CandidateList::printAllCandidates() const
{
	if (first == nullptr)
		cerr << "     => List is empty." << endl;
	else
	{
		Node *current = first;

		while (current != nullptr)
		{
			current->getCandidate().printCandidateInfo();
			cout << endl;
			current = current->getLink();
		}
	}
}

// printCandidateDivisionVotes
void CandidateList::printCandidateDivisionVotes(int sSNum, int divisionNum) const
{	
	if (first == nullptr)
		cerr << "     => List is empty." << endl;
	else
	{
		Node *current = first;
		bool isFound = false;

		while (current != nullptr && !isFound)
		{
			if (current->getCandidate().getSSN() == sSNum)
				isFound = true;	
			else
				current = current->getLink();
		}

		if (isFound)
			cout << "    => Division " << divisionNum << ": "
				 << current->getCandidate().getVotesByDivision(divisionNum)
				 << endl;
	}
}

// printCandidateTotalVotes
void CandidateList::printCandidateTotalVotes(int sSNum) const
{
	if (count == 0)
		cerr << "     => List is empty." << endl;
	else
	{
		Node *current = first;
		bool isFound = false;

		while (current != nullptr && !isFound)
		{
			if (current->getCandidate().getSSN() == sSNum)
				isFound = true;				
			else
				current = current->getLink();
		}

		if (isFound)
			cout << "    => Total votes: " 
				 << current->getCandidate().getTotalVotes() << endl;
	}
}

// destroyList
void CandidateList::destroyList()
{
	Node *current = first;

	while (first != nullptr)
	{
		first = first->getLink();
		delete current;
		current = first;
	}
	
	last = nullptr;
	count = 0;
}

// destructor
CandidateList::~CandidateList()
{
	destroyList();
}