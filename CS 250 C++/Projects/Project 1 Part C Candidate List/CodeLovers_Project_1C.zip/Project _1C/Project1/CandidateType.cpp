/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 17, 2018

	Project 1C
*/

#include "CandidateType.h"

//default constructor
CandidateType::CandidateType()
{
	totalNumOfVotes = 0;

	for (int i = 0; i < NUM_OF_DIVISIONS; ++i)
	{
		votes[i] = 0;
	}	
}

//function updateVotesByDivision
void CandidateType::updateVotesByDivision(int divisionNum, int numOfVotes)
{
	votes[divisionNum] = numOfVotes;
	totalNumOfVotes += numOfVotes;
}

//function getTotalVotes
int CandidateType::getTotalVotes() const
{
	return totalNumOfVotes;
}

//funtion getVotesByDivision
int CandidateType::getVotesByDivision(int divisionNum) const
{
	return votes[divisionNum - 1];
}

//function printCandidateInfo
void CandidateType::printCandidateInfo() const
{
	if(getFirstName() == "" || getLastName() == "" || getSSN() == 0)
		cerr << "No information available for this candidate.";
	else
		printPersonInfo();		
}

//function printCandidateTotalVotes
void CandidateType::printCandidateTotalVotes() const
{
	printName();
	cout << "    => Total votes: " << getTotalVotes();
}

//function printCandidateDivisionVotes
void CandidateType::printCandidateDivisionVotes(int divisionNum) const
{
	printName();
	cout << "    => Division " << divisionNum << " Total votes: "
		<< votes[divisionNum - 1];
}

//destructor
CandidateType::~CandidateType() { }