/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 17, 2018

	Project 1C
*/

#ifndef CANDIDATELIST_H
#define CANDIDATELIST_H

#include "CandidateType.h"

#include <iostream>
#include <string>

using namespace std;

class Node
{
public:
	Node() : link(nullptr) {}
    Node(const CandidateType& votes, Node *theLink) 
		: candidate(votes), link(theLink){}
    Node* getLink( ) const { return link; }
	CandidateType getCandidate( ) const { return candidate; }
    void setCandidate(const CandidateType& votes) { candidate = votes; }
    void setLink(Node *theLink) { link = theLink; }
	~Node() {}
private:
    CandidateType candidate;
    Node *link;		//pointer that points to next node
};

class CandidateList
{
public:
	// default constructor
	CandidateList();

	// addCandidate
	void addCandidate(const CandidateType& newCandidate);

	// getWinner
	int getWinner() const;

	// searchCandidate
	bool searchCandidate(int sSNum);

	// printCandidateName
	void printCandidateName(int sSNum) const;

	// printAllCandidates
	void printAllCandidates() const;

	// printCandidateDivisionVotes
	void printCandidateDivisionVotes(int sSNum, int divisionNum) const;

	// printCandidateTotalVotes
	void printCandidateTotalVotes(int sSNum) const;

	// destroyList
	void destroyList();

	// destructor
	~CandidateList();

private:
	Node *first; 	// pointer to point to the first candidate in the list
	Node *last;		// pointer to point to last candidate in the list
	int count;		// keeps track of number of candidates in the list
};

#endif
