/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 03, 2018

	Project 1_A
*/

#include "PersonType.h"

#include <iostream>
#include <string>

using namespace std;

int main()
{
	PersonType myType;
	myType.setPersonInfo("Da", "Nguyen", 333224444);

	cout << "===========================================" << endl;
	cout << "TEST: getFirstName...\n" << endl;
	cout << myType.getFirstName() << endl;

	cout << "===========================================" << endl;
	cout << "TEST: getLastName...\n" << endl;
	cout << myType.getLastName() << endl;
	
	cout << "===========================================" << endl;
	cout << "TEST: getSSN...\n" << endl;
	cout << myType.getSSN() << endl;

	cout << "===========================================" << endl;
	cout << "TEST: printName...\n" << endl;
	myType.printName();

	cout << "===========================================" << endl;
	cout << "TEST: printSSN...\n" << endl;
	myType.printSSN();

	cout << endl << "===========================================" << endl;
	cout << "TEST: printPersonInfo...\n" << endl;
	myType.printPersonInfo();
	cout << "===========================================" << endl;

	cout << endl;
	system("Pause");
	return 0;
}