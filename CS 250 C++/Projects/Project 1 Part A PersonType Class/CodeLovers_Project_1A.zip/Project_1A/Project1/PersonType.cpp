/*
	Nguyen, Da
	Ton, An
	Banh, Alex

	CS A250
	March 03, 2018

	Project 1_A
*/

#include "PersonType.h"

// default constructor
PersonType::PersonType()
{
	ssn = 0;
}

// overloaded constructor
PersonType::PersonType(const string& nFirstName, const string& nLastName, int newSSN)
{
	firstName = nFirstName;
	lastName = nLastName;
	ssn = newSSN;
}

// function setPersonInfo
void PersonType::setPersonInfo(const string& nFirstName, const string& nLastName, int newSSN)
{
	firstName = nFirstName;
	lastName = nLastName;
	ssn = newSSN;
}

// function getFirstName
string PersonType::getFirstName() const
{
	return firstName;
}

// function getLastName
string PersonType::getLastName() const
{
	return lastName;
}

// function getSSN
int PersonType::getSSN() const
{
	return ssn;
}

// printName
void PersonType::printName() const
{
	cout << lastName << ", " << firstName << endl;
}

// function printSSN
void PersonType::printSSN() const
{
	cout << (ssn / 1000000) << "-";
	cout << (ssn % 1000000 / 10000) << "-";
	cout << (ssn % 10000) << " ";
}

// function printPersonInfo
void PersonType::printPersonInfo() const
{
	printSSN();

	cout << firstName << " " << lastName << endl;
}

// destructor
PersonType::~PersonType() { }
