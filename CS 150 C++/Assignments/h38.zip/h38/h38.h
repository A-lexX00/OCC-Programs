/**
    @file h38.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H38_H_
#define H38_H_
#include <string>
using uchar = unsigned char;

class Image
{
public:
    explicit Image(const std::string& path);
    ~Image();

    struct Pixel {uchar red=0, green=0, blue=0, alpha=255;};
    Pixel& operator[](unsigned pos);

    unsigned width() const;
    unsigned height() const;
    unsigned size() const;

    bool save(const std::string& path);

    // Prevent copying
    Image& operator=(const Image&) = delete;
    Image(const Image&) = delete;

private:
    unsigned width_ = 0, height_ = 0;
    uchar * pixels_;
};

unsigned inline Image::width() const { return width_; }
unsigned inline Image::height() const { return height_; }
unsigned inline Image::size() const { return width_ * height_; }

// Image stacking
std::string stackImages(const std::string& inputDirectory,
                        const std::string& outputPath);
#endif
