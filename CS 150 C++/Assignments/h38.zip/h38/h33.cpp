/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h33.cpp
 */
#include <string>
#include <iostream>
#include <stdexcept>
#include <cstring>
// Other headers if necessary
using namespace std;

// For stb_image implementation
#define STB_IMAGE_IMPLEMENTATION        // REQUIRED (loading)
#define STB_IMAGE_WRITE_IMPLEMENTATION  // (writing)
#define STBI_FAILURE_USERMSG            // user messages
#include "stb_image.h"                  // "header-only" C libraries
#include "stb_image_write.h"

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h33.h"

// Add your code here

Image::Image(unsigned width, unsigned height):
    width_{width}, height_{height}, pixels_(width * height)
{}

Image::Image(const string& path)
{
    load(path);
}

void Image::fill(uchar red, uchar green, uchar blue, uchar alpha)
{
    Pixel value{red, green, blue, alpha};
    pixels_.assign(size(), value);
}


Image::Pixel& Image::at(unsigned pos)
{
    return pixels_.at(pos);
}

Image::Pixel& Image::at(unsigned x, unsigned y)
{
    return pixels_.at((y * width()) + x);
}

bool Image::load(const string& path)
{
    const int CHANNELS = 4;
    int width, height, bpp;
    auto p = stbi_load(path.c_str(),
            &width, &height, &bpp, CHANNELS);
    if (p)
    {
        width_ = width;
        height_ = height;
        pixels_.resize(width * height);
        auto data = p;
        for (auto& pixel : pixels_)
        {
            pixel = {data[0], data[1], data[2], data[3]};
            data += 4;
        }
        stbi_image_free(p);
        return true;
    }
    return false;
}

bool Image::save(const string& path)
{
    const int CHANNELS = 4;
    const int QUALITY = 100;
    auto dot = path.rfind('.');
    if (dot != string::npos)
    {
        string ext = path.substr(dot + 1);
        for (char& c : ext) c = tolower(c);
        if (ext == "png")
            return stbi_write_png(path.c_str(), width(), height(), CHANNELS,
                reinterpret_cast<unsigned char*>(pixels_.data()),
                width() * CHANNELS);
        else if (ext == "jpg")
            return stbi_write_jpg(path.c_str(), width(), height(), CHANNELS,
                reinterpret_cast<unsigned char*>(pixels_.data()),
                QUALITY);
        else if (ext == "bmp")
            return stbi_write_bmp(path.c_str(), width(), height(), CHANNELS,
                reinterpret_cast<unsigned char*>(pixels_.data()));

        else return false;
    }
    return false;
}

