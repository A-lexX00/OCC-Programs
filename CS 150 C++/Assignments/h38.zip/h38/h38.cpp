/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h38.cpp
 */
#include <string>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <memory>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

///////////////// LEAVE THESE AS IS /////////////////////////////
#define STB_LEAKCHECK_IMPLEMENTATION
#include "leak_check.h"
#define STB_IMAGE_IMPLEMENTATION        // REQUIRED (loading)
#define STB_IMAGE_WRITE_IMPLEMENTATION  // (writing)
#include "stb_image.h"                  // "header-only" C libraries
#include "stb_image_write.h"
///////////////// LEAVE THESE AS IS /////////////////////////////

#include "h38.h"

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

// Implement the class for part 1


// Complete this for part 2

string stackImages(const string& inputPath, const string& outputPath)
{
    
    return "Fail";
}
