#include "h38.h"
int main()
{
    Image pic("input/cpp.png");
    for (size_t i = 0, len = pic.size(); i < len; i++)
    {
        Image::Pixel& p = pic[i];
        p.red = 255 - p.red;
        p.green = 255 - p.green;
        p.blue = 255 - p.blue;
    }
    pic.save("actual/cpp-neg.png");
}