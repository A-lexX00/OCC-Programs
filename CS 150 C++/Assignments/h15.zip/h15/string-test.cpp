#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;
#include "h15.h"

int main()
{
    try 
    {
        cout << "stoi(\"42\")->" << stoi("42") << endl;
        cout << "stod(\"3.14159\")->" << stod("3.14159") << endl;
        cout << "stoi(\"3.14159\")->" << stoi("3.14159") << endl;
        cout << "stod(\"4NonBlondes\")->" << stod("4NonBlondes") << endl;
        cout << "stoi(\"UB-40\")->" << stoi("UB-40") << endl;
    }
    catch (const invalid_argument& e)
    {
    	cerr << "ERROR: " << e.what() << endl;
    }
    cout << "-program done-" << endl;
    
}
