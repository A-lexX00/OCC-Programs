/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h15.cpp
 */
#include <string>
#include <sstream>
#include <stdexcept>
#include <limits>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h15.h"

