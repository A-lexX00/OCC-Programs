/**
    @file h34.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
    DO NOT MODIFY IN ANY WAY
*/
#ifndef H34_H_
#define H34_H_

// DO NOT MODIFY THIS FILE IN ANY WAY

#include <string>
#include "person.h"  // You created this in lab

class Employee
{
public:
    Employee();
    Employee(const std::string& name, double salary);
    void salary(double newSalary);
    double salary() const;
    std::string name() const;
private:
    Person personData_;
    double salary_;
};

#endif
