/**
 * @file person.h
 * @author Stephen Gilbert
 * @version Fall 2017 homework.
 */
#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person
{
public:
    Person();
    Person(const std::string& name, int age);
    std::string name() const;
    int age() const;
private:
    std::string name_;
    int age_;  // 0 if unknown
};

#endif
