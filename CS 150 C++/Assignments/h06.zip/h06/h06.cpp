/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h06.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string STUDENT = "WHO ARE YOU?";  // Add your Canvas login name
extern string ASSIGNMENT;

/**
 * Describe the purpose of your program here.
 * @return 0 for success.
 */
int run()
{
    /*
        Implementation comments.
        Describe the inputs, outputs, given values
        and calculations here.
    */
    
	// 1. Title and heading
	cout << STUDENT << "-" << ASSIGNMENT << "-Number Sumer" << endl;
	cout << "-----------------------------------------" << endl;

	// 2. Input section
	cout << "Enter a string: ";
	string str;
	getline(cin, str);

	// 3. Processing section
	int sum = -1;
	
        
    // Your code goes here


	// 4. Output section
	cout << "The sum is [" << sum << "]" << endl;

    return 0;
}
