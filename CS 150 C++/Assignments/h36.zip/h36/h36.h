/**
    @file h36.h
    @author (Your name goes here)
    @version (Put the date here)
*/
#ifndef H36_H_
#define H36_H_

#include <string>
#include "account.h" 

//////////// Add the declarations for the Bank class here //////
class Bank 
{
    /////// FILL IN THIS PART YOURSELF

    
    // DO NOT ADD ANY OTHER data members
private:
    Account checking, savings;
};

#endif
