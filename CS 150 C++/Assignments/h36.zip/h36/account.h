#ifndef ACCOUNT_H
#define ACCOUNT_H
// DO NOT CHANGE THIS IN ANY WAY
class Account
{
public:
    Account();
    explicit Account(double);
    double balance() const;
    void deposit(double amt);
    void withdraw(double amt);
private:
    double balance_;
};

#endif
