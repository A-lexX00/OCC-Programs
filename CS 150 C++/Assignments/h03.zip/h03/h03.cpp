/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h03.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include <iostream>
#include <string>
using namespace std;

string STUDENT = "Your LoginID";  // Add your Canvas login name
extern string ASSIGNMENT;


/**
 * Describe the purpose of your program here.
 * @return 0 for success.
 */
int run()
{
    /*
        Implementation comments.
        Describe the inputs, outputs, given values
        and calculations here.
    */
    
    // Your code goes here
    
    return 0;
}
