/**
 * Informal tests for the Time class.
 * @author Steve Gilbert
 * @version Fall 2017
 *
 */
#include <iostream>
using namespace std;

#include "h31.h"

int main()
{
    // Add any code you like here
    // Run it by typing make tester
    
    Time t;         // a Time object
    t.setHours(18); // set the hours to 18
    cout << t.getHours() << endl;
}


