/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h31.cpp
 */
#include <string>
#include <stdexcept>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h31.h"

// Implement member functions here

