/**
    @file h35.h
    @author Your name goest here
    @version what day and meeting time
*/
#ifndef H35_H_
#define H35_H_
#include <iostream>
#include <string>

// Add your class definition and non-member prototypes here


#endif
