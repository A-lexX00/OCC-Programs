/**
 * Example program for h35
 * @author Stephen Gilbert
 * @version Fall 2017
 */
#include "h35.h"        // placed here to catch header errors
#include <iostream>
using namespace std;

int main()
{
    Fraction a(3, 6); // 1/2 after reducing
    Fraction b(1, 3); // 1/3
    Fraction c(1, 6); // 1/6

    Fraction sum = a + b + c;

    cout << a << " + " << b << " + " << c
        << " = " << sum << endl;
    
    // try subtraction, multiplication and division 
    // on your own.
}
