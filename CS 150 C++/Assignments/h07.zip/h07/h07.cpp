/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h07.cpp
 */
#include <string>
// Add aditional headers here if needed

using namespace std;

string STUDENT = "WHO AM I?";   // Add your name Canvas/occ-email ID

#include "h07.h"

// Place the implementation (definition) of your function here
