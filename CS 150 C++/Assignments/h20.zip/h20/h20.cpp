/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h20.cpp
 */
#include <string>
#include <vector>
#include <stdexcept> // remove
#include <fstream>  // remove
#include <cctype>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h20.h"

// Complete these two functions
vector<string> fileToWords(const string& filename)
{
    vector<string> result;
    // your code here
    return result;
}


/**
    Reads any stream until end-of-file. Returns a vector of misspelled words,
    but not those words that have been excluded.
    @param in the stream to read from
    @param dictionary vector of string containing correct-spelled words.
    @param excluded vector of string containing words to ignore.
    @return a vector of misspelled words, along with their position in the
        original file.
*/
vector<WORD> spellCheck(istream& in,
                        const vector<string>& dictionary,
                        const vector<string>& excluded)
{
    vector<WORD> result;
    return result;
}
