/**
    @file h23.h
    @author YOUR NAME HERE
    @version what day and meeting time
*/
#ifndef H23_H_
#define H23_H_
#include <vector>
#include <string>
#include <iostream>
////////////// DEFINE YOUR STRUCTURES HERE ///////////////////////

/**
    Enrolls a student in a course.
    @param s the student to entroll.
    @param c the course to enroll the student in.
*/
void enroll(Student* s, Course* c);

/**
    Prints a student and the courses enrolled in.
    @param o the stream to print the output on
    @param s a pointer to a const Student object
    @return the output stream
*/
std::ostream& operator<<(std::ostream& out, const Student* s);


/**
    Prints a course name and the students enrolled in it.
    @param o the stream to print the output on
    @param s a pointer to a const Course object
    @return the output stream
*/
std::ostream& operator<<(std::ostream& out, const Course* s);

#endif
