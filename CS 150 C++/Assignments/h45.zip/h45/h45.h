/**
    @file h45.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H45_H_
#define H45_H_
#include <string>
#include <iostream>
#include <fstream>
/**
 * Uses steganography to hide a text file inside a bitmap file.
 * @param bitmapfile name of the bitmap file to start with.
 * @param textfile the text file to embed.
 * @param outputfile the name of the bitmap file to create
 * @return true if successful, false otherwise.
 */
bool hideMessage(const char * bitmapfile, const char * textfile, const char * outputfile);

/**
 * Decode the hidden message (if it exists) in the bitmap file.
 * @param bitmapfile
 * @return the hidden message.
 */
std::string decodeMessage(const char * bitmapfile);

/**
 * Read an unsigned int from a stream.
 * @param in the stream to read from.
 * @param pos the position to start reading.
 */
unsigned getUInt(std::istream& in, std::ios::pos_type pos);

/**
 * Read an unsigned short (2 bytes) from a stream.
 * @param in the stream to read from.
 * @param pos the position to start reading.
 */
unsigned short getUShort(std::istream& in, std::ios::pos_type pos);

#endif
