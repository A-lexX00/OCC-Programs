/**
    CS 150 Homework Problem 38
    Hides a message in a picture.
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cerrno>
using namespace std;

#include "h33.h"

/**
 * Rule for encoding characters into 6 bits.
 * @param ch the character to encode
 * @param result the array where the result will be put.
 */
static void encode(char ch, unsigned char result[] /* should be 6 bytes long */)
{
	ch = static_cast<char>(toupper(ch)); // all lower to upper
	if (ch == '\n') ch = 95; // underscore
	ch = static_cast<char>(ch - 32); // compress all control characters except newline

    result[5] = ch % 2;			// low order bit 0
    result[4] = ch / 2 % 2;		// bit 1
    result[3] = ch / 4 % 2;		// bit 2
    result[2] = ch / 8 % 2;		// bit 3
    result[1] = ch / 16 % 2;	// bit 4
    result[0] = ch / 32 % 2;	// bit 5
}

/**
 * Uses steganography to hide a text file inside a bitmap file.
 * @param infile name of the bitmap file to start with.
 * @param textfile the text file to embed.
 * @param outfile the name of the bitmap file to create
 * @return true if successful, false otherwise.
 */
bool hideMessage(const char * infile, const char * textfile, const char * outfile)
{
    // open input file
	fstream fin;
	fin.open(infile, ios::in | ios::binary);
    if (! fin)
    {
        cerr << "Could not open " << infile
             << ": " << strerror(errno) << endl;
        return false;
    }

    // open text file
	ifstream tin;
	tin.open(textfile);
    if (! tin)
    {
        cerr << "Could not open " << textfile
             << ": " << strerror(errno) << endl;
        fin.close();
        return false;
    }

    // open output file
	fstream fout;
	fout.open(outfile, ios::out | ios::binary);
    if (! fout)
    {
        fin.close();
		tin.close();
		cerr << "Could not create " << outfile
		     << ": " << strerror(errno) << endl;
        return false;
    }

    // 4. Get the image dimensions from the header
    const unsigned FILE_TYPE = 0;
    const unsigned FILE_SIZE = 2;
    const unsigned IMG_START = 10;
    const unsigned IMG_WIDTH = 18;
    const unsigned IMG_HEIGHT = 22;

    unsigned short fileType = getUShort(fin, FILE_TYPE);
    unsigned fileSize = getUInt(fin, FILE_SIZE);
    unsigned imgStart = getUInt(fin, IMG_START);
    unsigned imgWidth = getUInt(fin, IMG_WIDTH);
    unsigned imgHeight = getUInt(fin, IMG_HEIGHT);

    // 5. Calculate scan line size. Must occupy multiples of four bytes
    int scanlineSize = imgWidth * 3;
    int padding = 0;
    if (scanlineSize % 4 != 0)
    {
        padding = 4 - scanlineSize % 4;
    }

    // 6. See if we have the correct kind of file
    fin.seekg(0, ios::end); // go to the end of the file
    std::streamoff actualFileSize = fin.tellg();
    if (fileType != 0x4d42 /* BM reversed */ && fileSize != actualFileSize)
    {
        cerr << "Not a 24-bit true color image file." << endl;
        return false;
    }

    // write outfile's header file
    char * headerInfo = new char[imgStart];
    fin.seekg(0);
    fin.read(headerInfo, imgStart);
    fout.write(headerInfo, imgStart);

    fin.seekg(imgStart);
    unsigned char pixel[3];
    // iterate over infile's scanlines
    for (size_t r = 0; r < imgHeight; r++)
    {
        // iterate over pixels in scanline
        for (size_t c = 0; c < imgWidth; c += 2)
        {
            // Store the encoded character in the array a
            char ch = 0;
            if (tin) tin.get(ch);   // Read a character from text file
            unsigned char a[6] = {0};        // Create empty array
            encode(ch, a);          // Pack the character into the array

            // read pixel from infile
            fin.read((char *)pixel, sizeof(pixel));

            // zero out low order bit
            // place first 3 bits into this pixel
            pixel[0] = static_cast<unsigned char>((pixel[0] / 2 * 2) + a[0]);
            pixel[1] = static_cast<unsigned char>((pixel[1] / 2 * 2) + a[1]);
            pixel[2] = static_cast<unsigned char>((pixel[2] / 2 * 2) + a[2]);

            // write pixel to outfile
            fout.write((char *)pixel, sizeof(pixel));

            // read next pixel from infile
            fin.read((char *) pixel, sizeof(pixel));

            // zero out low order bit
            // place last 3 bits into this pixel
            pixel[0] = static_cast<unsigned char>((pixel[0] / 2 * 2) + a[3]);
            pixel[1] = static_cast<unsigned char>((pixel[1] / 2 * 2) + a[4]);
            pixel[2] = static_cast<unsigned char>((pixel[2] / 2 * 2) + a[5]);

            // write pixel to outfile
            fout.write((char *)pixel, sizeof(pixel));
        }

        // skip over padding, if any
        fin.seekg(padding, ios::cur);

        // write padding to outfile
        for (int k = 0; k < padding; k++)
            fout.put(0);
    }

    // close all the files
    fin.close();
	tin.close();
    fout.close();

    // that's all folks
    return true;
}

/**
 * Read an unsigned int from a stream.
 * @param in the stream to read from.
 * @param pos the position to start reading.
 */
unsigned getUInt(istream& in, ios::pos_type pos)
{
    in.seekg(pos);
    unsigned result;
    in.read((char*) &result, sizeof(int));
    return result;
}

/**
 * Read an unsigned short (2 bytes) from a stream.
 * @param in the stream to read from.
 * @param pos the position to start reading.
 */
unsigned short getUShort(istream& in, ios::pos_type pos)
{
    in.seekg(pos);
    unsigned short result;
    in.read((char*) &result, sizeof(int));
    return result;
}
