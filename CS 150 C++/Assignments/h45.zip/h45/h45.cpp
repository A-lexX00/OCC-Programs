/**
    CS 150 Homework Problem
    Decoding a binary file.
    @author <your name>
    @date <the semester and section>
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cerrno>
using namespace std;

string STUDENT = "Who am I?";     // Add your Canvas/occ-email ID

#include "h45.h"

/**
 * Read an unsigned int from a stream.
 * @param in the stream to read from.
 * @param pos the position to start reading.
 */
unsigned getUInt(istream& in, ios::pos_type pos)
{
    in.seekg(pos);
    unsigned result;
    in.read((char*) &result, sizeof(int));
    return result;
}

/**
 * Read an unsigned short (2 bytes) from a stream.
 * @param in the stream to read from.
 * @param pos the position to start reading.
 */
unsigned short getUShort(istream& in, ios::pos_type pos)
{
    in.seekg(pos);
    unsigned short result;
    in.read((char*) &result, sizeof(int));
    return result;
}

char decode(unsigned char a[] /* should be 6 bytes long */)
{
	char ch = 32 + a[5] + a[4] * 2 + a[3] * 4 + a[2] * 8 + a[1] * 16 + a[0] * 32;
	if (ch == 95) ch = '\n';
	return ch;
}


/**
 * Decode the hidden message (if it exists) in the bitmap file.
 * @param bitmapfile the name of the file to decode.
 * @return the hidden message.
 */
string decodeMessage(const char * infile)
{
    // Your code will go here
    return "";  // REPLACE THIS, OF COURSE
}

