/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h22.cpp
 */
#include <string>
#include <iostream>
// Other headers if necessary
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h22.h"

// Add your code here
void negative(unsigned char * const img, int width, int height)
{
}

void flip(unsigned char * const img, int width, int height)
{
}

void greenScreen(unsigned char * const img, int width, int height)
{
}

void composite(unsigned char * const bg, unsigned char * const fg,
                int width, int height)
{

}

