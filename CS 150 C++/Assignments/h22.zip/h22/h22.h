/**
    @file h22.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H22_H_
#define H22_H_

/**
 * Reverses (inverts) every pixel in img, except any alpha pixels.
 * @param data a constant pointer to the image data.
 * @param width the width of the image in pixels
 * @param height the height of the image in pixels
 * Assume 4 bits per pixel
 */
void negative(unsigned char * const img, int width, int height);

/**
 * Flips the image horizontally.
 * @param data a constant pointer to the image data.
 * @param width the width of the image in pixels
 * @param height the height of the image in pixels
 * Assume 4 bytes per pixel
 */
void flip(unsigned char * const img, int width, int height);

/**
 * Sets all green pixels to transparent.
 * A pixel is green if the green component is at least twice as large
 * as the maximum of its red and blue components.
 * @param data a constant pointer to the image data.
 * @param width the width of the image in pixels
 * @param height the height of the image in pixels
 * Assume that there are 4 bytes per pixel (RGBA)
 */
 
void greenScreen(unsigned char * const img, int width, int height);

/**
 * Combines a background and foreground. The foreground
 * is "green-screened". The pixels are combined with
 * opaque pixels from foreground and backround showing
 * through the transparent ones.
 * @param data a constant pointer to the image data.
 * @param width the width of the image in pixels
 * @param height the height of the image in pixels
 *  - Assume that there are 4 bytes per pixel (RGBA)
 *  - Asume both images are the same size.
 */
void composite( unsigned char * const bg, 
                unsigned char * const fg,
                int width, int height);

#endif
