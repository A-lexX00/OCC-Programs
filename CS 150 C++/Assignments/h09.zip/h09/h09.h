// Write the interface to your library here
