/**
    @file h18.h
    @author YOUR NAME HERE
    @date what day and meeting time
    Declarations for CS 150 Homework
*/
#ifndef H18_H_
#define H18_H_
#include <string>

struct Alien
{
    long long age; // age in eons
    std::string name;
};


enum class Coin 
{
    PENNY = 1,
    NICKEL = 5,
    DIME = 10,
    QUARTER = 25,
    HALF = 50
};

// Prototype the rest of the functions and operators



#endif
