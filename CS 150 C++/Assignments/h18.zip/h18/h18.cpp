/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h18.cpp
 */
#include <string>
#include <iostream>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h18.h"

// Add your implementation here

