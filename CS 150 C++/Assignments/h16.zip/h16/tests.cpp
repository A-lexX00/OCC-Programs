/**
 *  @author Stephen Gilbert
 *  @version Tests for CS 150 homework
 *  @file tests.cpp
 */
#include <iostream>
#include <string>
#include <iomanip>
#include <cstdlib>
using namespace std;

#include "cs150check.h"
#include "h16.h"

/**
 * Run your program's tests
 */
void runTests()
{

	//    ///////////// Begin a set of tests
    beginTests(); // test heading
    beginFunctionTest("Compiling under two different platforms.");
    if (system("clang++ string-test.cpp 2>/dev/null"))
        failMsg("Cannot compile under C++ 98", 5);
    else
        passMsg("Compiles under C++ 98", 5);

    if (system("clang++ -std=c++11 string-test.cpp 2>/dev/null"))
        failMsg("Cannot compile under C++ 11", 5);
    else
        passMsg("Compiles under C++ 11", 5);
    endFunctionTest();
    
#if __cplusplus <= 199711L
    cerr << "Testing using C++98" << endl;
    cerr << "------------------------------------------" << endl;
#else
    cerr << "Testing using C++11 or greater" << endl;
    cerr << "------------------------------------------" << endl;
#endif
    beginFunctionTest("to_string function");
    assertEqualsMsg("to_string(42)", "42", to_string(42));
    assertEqualsMsg("to_string(3.F)", "3.000000", to_string(3.F));
    assertEqualsMsg("to_string(-1U)", "4294967295", to_string(-1U));
    assertEqualsMsg("to_string(4L)", "4", to_string(4L));
    assertEqualsMsg("to_string('c')", "99", to_string('c'));
    assertEqualsMsg("to_string(1.7L)", "1.700000", to_string(1.7L));
    assertEqualsMsg("to_string(2.7e3)", "2700.000000", to_string(2.7e3));
    assertEqualsMsg("to_string(2.17e-4)", "0.000217", to_string(2.17e-4));
    assertEqualsMsg("to_string(1.0/0.0)", "inf", to_string(1.0/0.0));
    assertEqualsMsg("to_string(-1.0/0.0)", "-inf", to_string(-1.0/0.0));
    assertEqualsMsg("to_string(0.0/0.0)", "nan", to_string(0.0/0.0));

    endFunctionTest();

    endTests();
}

