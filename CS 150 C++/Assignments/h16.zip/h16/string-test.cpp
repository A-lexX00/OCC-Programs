#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;
#include "h16.h"

int main()
{
    cout << "to_string(15)->" << to_string(15) << endl;
    cout << "to_string(3.14159)->" << to_string(3.14159) << endl;
}

