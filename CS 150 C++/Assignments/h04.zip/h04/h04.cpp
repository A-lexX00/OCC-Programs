/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h04.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string STUDENT = "WHO ARE YOU?";  // Add your Canvas login name
extern string ASSIGNMENT;

/**
 * Describe the purpose of your program here.
 * @return 0 for success.
 */
int run()
{
	// 1. Title and heading
	cout << STUDENT << "-" << ASSIGNMENT << "-Graduation Calculator" << endl;
	cout << "-----------------------------------------" << endl;

	// 2. Input section
	cout << "Enter your gpa, total credits and honors credits: ";
	double gpa;
	int credits, honorsCredits;
	cin >> gpa >> credits >> honorsCredits;

	// 3. Processing section
	string result = "invalid";
    // PUT YOUR CODE BELOW THIS LINE
    
    
    
    
    
    
    // PUT YOUR CODE ABOVE THIS LINE
	// 4. Output section
	cout << "The result is [\"" << result << "\"]" << endl;

    return 0;
}
