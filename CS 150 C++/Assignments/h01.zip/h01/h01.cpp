/**
 *  @author Put your name here
 *  @date Put the date here (Semester is OK)
 *  @file h01.cpp
 */
#include <iostream>
#include <string>
using namespace std;

string STUDENT = "WHO ARE YOU?";  // Add your Canvas login name
extern string ASSIGNMENT;

/**
 * One line describing what this program does.
 * @return 0 for success.
 */
int run()
{
    /*
        Implementation comments.
        Describe the inputs, outputs, given values
        and calculations here.
    */
    
    // Your code goes here
    
    return 0;
}
