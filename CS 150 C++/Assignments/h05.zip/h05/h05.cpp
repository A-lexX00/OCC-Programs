/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h05.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string STUDENT = "WHO AM I?";  // Add your Canvas login name
extern string ASSIGNMENT;

/**
 * Describe the purpose of your program here.
 * @return 0 for success.
 */
int run()
{
    /*
        Implementation comments.
        Describe the inputs, outputs, given values
        and calculations here.
    */
    
	// 1. Title and heading
	cout << STUDENT << "-" << ASSIGNMENT << "-Gender Assignment" << endl;
	cout << "-----------------------------------------" << endl;

	// 2. Input section
	cout << "Enter a French country name and I will supply its gender: ";
	string country;
	getline(cin, country);

	// 3. Processing section
	string result = "who knows?";
    
    // Your code goes here
    


	// 4. Output section
	cout << "The correct gender is [" << result << "]" << endl;

    return 0;
}
