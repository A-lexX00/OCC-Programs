/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h19.cpp
 */
#include <string>
#include <vector>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h19.h"

// Add your function here
