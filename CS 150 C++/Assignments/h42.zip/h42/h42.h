/*
 *  h42.h
 *  @author your name goes here
 *  @version your section and day
 *  Point->Circle->Cylinder
 */

#ifndef H42_H_
#define H42_H_

#include "point.h"
#include <cmath>
#include <string>

// Use this for PI
const double PI = std::acos(-1.0);

//////// Put your class definitions here /////////////////////





#endif
