/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h37.cpp
 */
#include <string>
#include <iostream>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h37.h"

// Implement the three member functions here
