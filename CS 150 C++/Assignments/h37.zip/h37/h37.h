/**
    @file h37.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H37_H_
#define H37_H_
#include <iostream>

const size_t INITIAL_CAPACITY = 2;

class FlexArray
{
public:
    // You will write these
    FlexArray& readData(std::istream& in);
    std::string toString() const;
    ~FlexArray();

    // These prohibit certain operations
    FlexArray() = default;
    FlexArray(const FlexArray&) = delete;
    FlexArray& operator=(const FlexArray&) = delete;
private:
    size_t size_ = 0;
    int * data_ = nullptr;
};

inline std::ostream& operator<<(std::ostream& out, const FlexArray& a)
{
    out << a.toString();
    return out;
}

inline std::istream& operator>>(std::istream& in, FlexArray& a)
{
    a.readData(in);
    return in;
}
#endif
