#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>
using namespace std;

#include "h30.h"

int main(int argc, const char * argv[])
{
    ostringstream out;
    out << "calc:";
    for (int i = 1; i < argc; i++)
        out << " " << argv[i];
    out << " -> ";

    try { out << calc4(argc, argv); }
    catch (runtime_error& e) { out << "Error: " << e.what(); }

    cout << out.str() << endl;
}

// Quick & Dirty Linking
#include "h30.cpp"