/**
    @file h30.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H30_H_
#define H30_H_

/**
 * Processes the command line, adding and subtracting operands.
 *
 * @param argc the number of arguments on the command line.
 * @param argv the array of command line arguments.
 * @return the result of the caluclation
 *
 * @throw runtime_error if illegal operator or not enough operand.
 *
 * @example
 *      ./calc 1 + 2 returns 3
 *      ./calc 2 - -2 returns 4
 *      ./calc 2 x 4 returns 8
 *      ./calc 5 / 2 returns 2.5
 *      ./calc 2 + 3 - throws  (Not enough operands)
 *      ./calc 2 + 3 % 4 throws (Illegal operand)
 */
double calc4(int argc, const char * argv[]);

#endif
