/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h25.cpp
 */
#include <string>
// Other headers if necessary
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h25.h"

// Implement the following functions

int alternatingSum(const int a[], size_t size)
{
    int sum = 0;
    
    // Your code goes here
    
    return sum;
}


MinMax minMax(const double *ptr, size_t size)
{
    MinMax result;
    
    // Your code goes here
    
    return result;
}

bool sameSet(const int *aBeg, const int *aEnd,
             const int *bBeg, const int *bEnd)
{
    // Add your code yere
    
    return true;
}
