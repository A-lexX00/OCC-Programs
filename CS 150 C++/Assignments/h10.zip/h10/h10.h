// Put the interface to the bar-code libary here
