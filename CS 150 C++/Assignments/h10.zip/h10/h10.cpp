/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h10.cpp
 */
#include <string>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h10.h"

// Put your function implementation (definitions) in this file
