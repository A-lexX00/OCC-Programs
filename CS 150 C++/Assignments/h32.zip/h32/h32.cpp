/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h32.cpp
 */
#include <string>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h32.h"

// Implement your member functions here
