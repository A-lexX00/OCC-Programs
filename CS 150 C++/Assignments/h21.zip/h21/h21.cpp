/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h21.cpp
 */
#include <string>
// Other headers if necessary
using namespace std;
#include "h21.h"

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

// Add your code here
