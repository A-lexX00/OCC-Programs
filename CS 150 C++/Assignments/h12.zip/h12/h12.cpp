/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h12.cpp
 */
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h12.h"

// Add your function here
