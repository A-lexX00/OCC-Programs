/**
    @file h12.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H12_H_
#define H12_H_

#include <string>

/**
 * Opens and searches in fileName for the searchPhrase
 * When found, prints the line number and line.
 * @param fileName name of the file.
 * @param searchPhrase phrase to search for.
 */
void searchFile(const std::string& fileName, const std::string& searchPhrase);


#endif
