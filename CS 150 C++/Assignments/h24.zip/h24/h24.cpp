/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h24.cpp
 */
#include <string>
#include <iostream>
// Other headers if necessary
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "h24.h"

// Add your code here
void translate(unsigned char * const img, int width, int height, int dx, int dy)
{
    // Add your code here
}


