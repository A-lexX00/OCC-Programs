/**
    @file h24.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef H24_H_
#define H24_H_

/**
 * Shifts an image in both the dx and dy directions.
 * Pixels wrap around as required.
 * @param data a constant pointer to the image data.
 * @param width the width of the image in pixels
 * @param height the height of the image in pixels
 * @param dx the amount to shift in the x dimension.
 * @param dy the amount to shift in the y dimension
 * Assume 4 bits per pixel
 */
void translate(unsigned char * const img, int width, int height, int dx, int dy);

#endif
