/**
 *  @file breakout.cpp
 *  @author your name and id goes here
 *  @version your day and time goes here
 */
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace std;
using namespace sf;

#include "breakout.h"

int main()
{
    RenderWindow win(VideoMode(APP_WIDTH, APP_HEIGHT), // mode
			"Steve Gilbert's Breakout");
    Game game;
    init(game, &win);
    run(game);
}

void init(Game& game, RenderWindow * win)
{
    game.window = win;
    game.window->setFramerateLimit(60);
}
/**
    Private methods for running the game.
*/
static void processEvents(Game& game);
static void update(Game& game);
static void render(Game& game);

/**
    Run's the "game loop" for the game.
    @param g the initialized game
*/
void run(Game& g)
{
    while (g.window->isOpen())
    {
        processEvents(g);
        update(g);
        render(g);
    }
}
/**
    Put code for handling events that occur here.
    @param g the game.
*/
static void processEvents(Game& g)
{
    Event e;
    while (g.window->pollEvent(e))
    {
        if (e.type == Event::Closed)
            g.window->close();
    }
}

/**
    Put code for handling gameplay update here.
    @param g the game.
*/
static void update(Game& g)
{
}

/**
    Put code for drawing the screen here.
    @param g the game.
*/
static void render(Game& g)
{
    g.window->clear(Color::Black);
    g.window->display();
}
