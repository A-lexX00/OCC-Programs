/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file h33.cpp
 */
#include <string>
#include <iostream>
#include <stdexcept>
#include <cstring>
// Other headers if necessary
using namespace std;

// For stb_image implementation
#define STB_IMAGE_IMPLEMENTATION        // REQUIRED (loading)
#define STB_IMAGE_WRITE_IMPLEMENTATION  // (writing)
#define STBI_FAILURE_USERMSG            // user messages
#include "stb_image.h"                  // "header-only" C libraries
#include "stb_image_write.h"

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID


#include "h33.h"

// Add your code here

